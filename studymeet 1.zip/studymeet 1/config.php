<?php
$link = mysql_connect('mysql-user-master.stanford.edu', 'ccs147gnaifeh', 'uuniesha');
mysql_select_db('c_cs147_gnaifeh');
?>